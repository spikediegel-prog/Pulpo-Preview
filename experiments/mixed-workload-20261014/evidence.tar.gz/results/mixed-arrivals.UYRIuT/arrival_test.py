"""Finite scheduled arrivals; disposable SQL and 30ms API-style fake only."""
import argparse
from collections import deque
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from contextlib import closing, contextmanager
from hashlib import sha256
import json
from pathlib import Path
import platform
import sqlite3
import subprocess
import sys
import tempfile
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.repo.resolve()))
from pulpo import GovernanceKernel, Intent, Policy, SQLiteKernelState
from pulpo.orchestrator import PulpoOrchestrator
from pulpo.traffic import Path as Route, TrafficControl, Backpressure

PAIRS = 30
REPEATS = 3
PERIODS_MS = (200, 100, 75, 50, 25)

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def p95(values):
    return sorted(values)[max(0, (95 * len(values) + 99) // 100 - 1)]

def run(mode, interval_ms):
    with tempfile.TemporaryDirectory(prefix='pulpo-arrivals-') as scratch:
        root = Path(scratch)
        effect_db = root / 'effects.sqlite'
        with closing(sqlite3.connect(effect_db)) as db, db:
            db.execute('PRAGMA synchronous=FULL')
            db.execute('CREATE TABLE effects (resource TEXT PRIMARY KEY)')
        state = SQLiteKernelState(root / 'governance.sqlite')
        try:
            kernel = GovernanceKernel(Policy(frozenset({'fixture_write'}), 0),
                secret=b'finite-arrival-fixture-only', state=state)
            owner = PulpoOrchestrator(kernel)
            jobs = [dict(lane=lane, intent=Intent('fixture', 'fixture_write',
                    f'fixture:{lane}:{index}'), pair=index, decision=None)
                    for index in range(PAIRS) for lane in ('sql', 'api')]
            router = None
            if mode == 'ptc':
                router = TrafficControl.for_sql_api(
                    tuple(Route(j['intent'].resource, j['lane'], j['intent']) for j in jobs),
                    sql_queue_limit=8, api_queue_limit=8)
            queues = {lane: deque() for lane in ('sql', 'api')}
            fifo = deque()
            pending = deque()
            active = {}
            occupied = dict(sql=0, api=0)
            limits = dict(sql=1, api=2)
            peaks = dict(sql=0, api=0)
            claims, completed = [], []
            cursor, blocked, backlog_peak = 0, 0, 0
            epoch = time.perf_counter() + 0.020
            for j in jobs:
                j['arrival'] = epoch + j['pair'] * interval_ms / 1000
            by_resource = {j['intent'].resource: j for j in jobs}
            stop_at = epoch + 30

            @contextmanager
            def direct(intent, permit):
                require(kernel.consume(permit, intent), 'FIFO permit rejected')
                yield

            def effect(lane, intent):
                if lane == 'sql':
                    with closing(sqlite3.connect(effect_db)) as db, db:
                        db.execute('PRAGMA synchronous=FULL')
                        db.execute('INSERT INTO effects VALUES (?)', (intent.resource,))
                    time.sleep(0.002)
                else:
                    time.sleep(0.030)
                return intent.resource

            with ThreadPoolExecutor(max_workers=3) as workers:
                while len(completed) < len(jobs):
                    now = time.perf_counter()
                    require(now < stop_at, 'bounded workload timed out')
                    while cursor < len(jobs) and jobs[cursor]['arrival'] <= now:
                        pending.append(jobs[cursor])
                        cursor += 1
                    backlog_peak = max(backlog_peak, len(pending))
                    # Finite caller backlog; original unused claims survive backpressure.
                    for _ in range(len(pending)):
                        j = pending.popleft()
                        if j['decision'] is None:
                            decision = kernel.evaluate(j['intent'])
                            require(decision.outcome == 'allow' and decision.permit,
                                    'fixture authorization denied')
                            j['decision'] = decision
                            claims.append((j['intent'], decision.permit))
                        if router is not None:
                            try:
                                router.enqueue(j['intent'], j['decision'],
                                               (j['intent'].resource,))
                            except Backpressure:
                                pending.append(j)
                                blocked += 1
                                continue
                        else:
                            if len(queues[j['lane']]) == 8:
                                pending.append(j)
                                blocked += 1
                                continue
                            queues[j['lane']].append(j)
                            fifo.append(j)
                        j['admission_ms'] = (time.perf_counter() - j['arrival']) * 1000
                    if router is not None:
                        for lane, value in router.snapshot().items():
                            require(value['queued'] <= 8, 'queue bound exceeded')
                            peaks[lane] = max(peaks[lane], value['queued'])
                    else:
                        for lane, queue in queues.items():
                            peaks[lane] = max(peaks[lane], len(queue))
                    while True:
                        if router is not None:
                            context = owner.traffic_dispatch(router)
                            dispatch = context.__enter__()
                            if dispatch is None:
                                context.__exit__(None, None, None)
                                break
                            j = by_resource[dispatch.work.intent.resource]
                        else:
                            if not fifo or occupied[fifo[0]['lane']] >= limits[fifo[0]['lane']]:
                                break
                            j = fifo.popleft()
                            require(queues[j['lane']].popleft() is j, 'FIFO order mismatch')
                            context = direct(j['intent'], j['decision'].permit)
                            context.__enter__()
                        lane = j['lane']
                        occupied[lane] += 1
                        require(occupied[lane] <= limits[lane], 'slot limit exceeded')
                        try:
                            future = workers.submit(effect, lane, j['intent'])
                        except BaseException:
                            occupied[lane] -= 1
                            context.__exit__(*sys.exc_info())
                            raise
                        active[future] = (j, context)
                    now = time.perf_counter()
                    next_arrival = jobs[cursor]['arrival'] if cursor < len(jobs) else stop_at
                    delay = max(0, min(next_arrival, stop_at) - now)
                    if not active:
                        require(not pending and not fifo, 'idle fixture with retained work')
                        time.sleep(delay)
                        continue
                    done, _ = wait(active, timeout=delay, return_when=FIRST_COMPLETED)
                    for future in done:
                        j, context = active.pop(future)
                        try:
                            require(future.result() == j['intent'].resource, 'effect target mismatch')
                        finally:
                            occupied[j['lane']] -= 1
                            context.__exit__(None, None, None)
                        completed.append(dict(lane=j['lane'], resource=j['intent'].resource,
                            admission_ms=j['admission_ms'],
                            latency_ms=(time.perf_counter() - j['arrival']) * 1000))
            require(not pending and not fifo and not active and not any(occupied.values()),
                    'retained work after completion')
            if router is not None:
                require(all(not v['queued'] and not v['active'] for v in router.snapshot().values()),
                        'router failed to drain')
            expected = sorted(j['intent'].resource for j in jobs)
            require(sorted(j['resource'] for j in completed) == expected, 'completion mismatch')
            with closing(sqlite3.connect(effect_db)) as db:
                require(db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok', 'database corrupt')
                require(sorted(r[0] for r in db.execute('SELECT resource FROM effects')) ==
                        sorted(j['intent'].resource for j in jobs if j['lane'] == 'sql'), 'rows mismatch')
            require(sum(r['event'] == 'permit_consumed' for r in kernel.audit) == len(jobs),
                    'permit count mismatch')
            require(kernel.verify_audit(), 'invalid audit')
            require(all(not kernel.consume(permit, intent) for intent, permit in claims),
                    'permit replay accepted')
            require(kernel.verify_audit(), 'invalid audit after replay checks')
            class_p95 = {lane: p95([j['latency_ms'] for j in completed if j['lane'] == lane])
                         for lane in ('sql', 'api')}
            return dict(mode=mode, interval_ms=interval_ms, class_p95_ms=class_p95,
                worst_ms=max(j['latency_ms'] for j in completed),
                misses_100ms=sum(j['latency_ms'] >= 100 for j in completed),
                queue_peaks=peaks, caller_backlog_peak=backlog_peak,
                backpressure_attempts=blocked, jobs=completed, correctness_passed=True,
                both_classes_p95_under_100ms=max(class_p95.values()) < 100)
        finally:
            state.close()

samples = []
for round_number in range(REPEATS):
    periods = PERIODS_MS if round_number % 2 == 0 else tuple(reversed(PERIODS_MS))
    for interval in periods:
        modes = ('fifo', 'ptc') if round_number % 2 == 0 else ('ptc', 'fifo')
        for mode in modes:
            row = run(mode, interval)
            row['round'] = round_number + 1
            samples.append(row)
            print(f"round {round_number + 1} {mode} every {interval}ms: "
                  f"SQL P95 {row['class_p95_ms']['sql']:.1f}ms; "
                  f"API P95 {row['class_p95_ms']['api']:.1f}ms; "
                  f"misses {row['misses_100ms']}/{PAIRS * 2}", flush=True)
            (args.output / 'partial.json').write_text(json.dumps(samples, indent=2) + '\n')
summary = []
for interval in PERIODS_MS:
    for mode in ('fifo', 'ptc'):
        rows = [r for r in samples if r['interval_ms'] == interval and r['mode'] == mode]
        jobs = [j for r in rows for j in r['jobs']]
        class_p95 = {lane: p95([j['latency_ms'] for j in jobs if j['lane'] == lane])
                     for lane in ('sql', 'api')}
        row = dict(mode=mode, interval_ms=interval, offered_pairs_per_second=1000 / interval,
            offered_jobs_per_second=2000 / interval, pooled_class_p95_ms=class_p95,
            rounds_passing=sum(r['both_classes_p95_under_100ms'] for r in rows),
            rounds=REPEATS, misses_100ms=sum(r['misses_100ms'] for r in rows),
            total_jobs=len(jobs), worst_ms=max(r['worst_ms'] for r in rows),
            max_caller_backlog=max(r['caller_backlog_peak'] for r in rows),
            max_sql_queue=max(r['queue_peaks']['sql'] for r in rows),
            max_api_queue=max(r['queue_peaks']['api'] for r in rows))
        summary.append(row)
        print(json.dumps(row), flush=True)
report = dict(source_sha=subprocess.check_output(
    ['git', '-C', str(args.repo), 'rev-parse', 'HEAD'], text=True).strip(),
    python=platform.python_version(), sqlite=sqlite3.sqlite_version,
    platform=platform.platform(), script_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
    pairs_per_round=PAIRS, repeats=REPEATS, queue_limit_per_lane=8,
    scope='Finite predeclared scheduled arrivals, no provider calls. Latency starts at '
          'scheduled arrival and ends after observed effect completion and slot release; '
          'includes caller backlog, authorization and admission. Initialization and final '
          'verification excluded. No warm-up samples excluded. Not a sustained capacity guarantee.',
    samples=samples, summary=summary)
(args.output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print('Report:', args.output / 'report.json')
